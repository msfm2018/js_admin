# wangEditor basic-modules

Basic modules built in [wangEditor](https://www.wangeditor.com/) by default.
