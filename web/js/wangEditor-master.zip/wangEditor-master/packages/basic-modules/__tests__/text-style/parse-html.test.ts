/**
 * @description parse html test
 * @author wangfupeng
 */

// import { $ } from 'dom7'
// import { parseStyleHtml } from '../../../../packages/basic-modules/src/modules/text-style/parse-style-html'

describe('text style - parse style html', () => {
  it('占位', () => {
    expect(1 + 1).toBe(2)
  })
  // TODO 执行以下代码会有 Dom7 一个怪异的 bug ，先暂且注释，后面再解决 wangfupeng 2022.01.17

  // it('bold', () => {
  //   const $text = $('<b></b>')
  //   const textNode = { text: 'hello' }

  //   // parse style
  //   const res = parseStyleHtml($text[0], textNode)
  //   expect(res).toEqual({
  //     text: 'hello',
  //     bold: true,
  //   })
  // })

  // // italic underline... 等
})
