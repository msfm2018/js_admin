/**
 * @description line-height config
 * @author wangfupeng
 */

export function genLineHeightConfig() {
  return ['1', '1.15', '1.5', '2', '2.5', '3']
}
