# wangEditor editor

[中文](./README.md)

Open source web rich text editor, run right out of the box. Support JS Vue React.

- [Document](https://www.wangeditor.com/en/)
- [Demo](https://www.wangeditor.com/demo/?lang=en)

![](../../docs/images/editor-en.png)

You can [commit an issue]((https://github.com/wangeditor-team/wangEditor/issues)) if you have any question.
