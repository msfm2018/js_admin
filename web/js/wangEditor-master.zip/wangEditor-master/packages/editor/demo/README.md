# wangEditor demo

修改左侧目录，在 demo 目录搜索 `MENU_CONF`

demo 部署参考 `deploy-demos.yml` 配置
