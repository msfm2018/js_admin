# wangEditor code highlight

Code highlight module built in [wangEditor](https://www.wangeditor.com/) by default.
