/**
 * @description 注册菜单，入口
 * @author wangfupeng
 */

import './register-button-menu'
import './register-select-menu'
import './register-modal-menu'
