# render test

各个 module `renderElem` 已经测试了该模块的代码。
