/**
 * @description formats helper
 * @author wangfupeng
 */

export function genElemId(id: string) {
  return `w-e-element-${id}`
}

export function genTextId(id: string) {
  return `w-e-text-${id}`
}
