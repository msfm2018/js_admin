/**
 * @description upload entry
 * @author wangfupeng
 */

import createUploader from './createUploader'
import { IUploadConfig } from './interface'

export { createUploader, IUploadConfig }

// TODO upload 能力，写到文档中，二次开发使用
