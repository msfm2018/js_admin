# menus

统一注册 menu ，menu 支持
- classic toolbar
- hovering toolbar
- tooltip
- contextMenu
