/**
 * @description create entry
 * @author wangfupeng
 */

import coreCreateEditor from './create-editor'
import coreCreateToolbar from './create-toolbar'

export { coreCreateEditor, coreCreateToolbar }
