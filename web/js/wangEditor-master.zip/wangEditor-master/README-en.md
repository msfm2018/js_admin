# wangEditor 5

[中文](./README.md)

## Introduction

Open source web rich text editor, run right out of the box. Support JS Vue React.

- [Document](https://www.wangeditor.com/en/)
- [Demo](https://www.wangeditor.com/demo/?lang=en)

![](./docs/images/editor-en.png)

## Communication

You can [commit an issue]((https://github.com/wangeditor-team/wangEditor/issues)) if you have any question.

## Donation

Support wangEditor open-source work https://opencollective.com/wangeditor
